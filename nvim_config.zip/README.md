# nvim_config
