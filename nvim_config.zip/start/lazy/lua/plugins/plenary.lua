return {
  'nvim-lua/plenary.nvim',
  lazy = true,
}
