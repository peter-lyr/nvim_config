return {
  {
    'dstein64/vim-startuptime',
    lazy = true,
    cmd = 'StartupTime',
  },
}
