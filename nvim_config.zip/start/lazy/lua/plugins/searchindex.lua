return {
  'google/vim-searchindex',
  event = { 'CursorMoved', },
}
