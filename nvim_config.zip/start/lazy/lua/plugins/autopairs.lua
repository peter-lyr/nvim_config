return {
  'windwp/nvim-autopairs',
  lazy = true,
  event = 'InsertEnter',
  opts = {},
}
