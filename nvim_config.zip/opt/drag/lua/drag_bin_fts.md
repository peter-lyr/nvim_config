bin
wav
mp3
mp4
hex
dcf
dll
exe
