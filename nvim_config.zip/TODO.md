1. [ ] del index.lock
2. [x] telescope startuptime
